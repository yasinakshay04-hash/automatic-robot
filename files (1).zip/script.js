/* ==========================================================================
   PAXEL COMMERCIAL DASHBOARD — SCRIPT.JS
   Struktur: CONFIG → STATE → UTILS → DATA → FILTERS → KPI → ALERTS →
             INSIGHTS → RANKING → CHARTS → TABLE → INIT
   ========================================================================== */

/* ==========================================================================
   1. CONFIG
   -------------------------------------------------------------------------
   Untuk menghubungkan Google Sheets:
   1) Di Google Sheets: File > Share > Publish to web > pilih sheet > format CSV
   2) Copy URL yang dihasilkan, tempel ke SHEET_CSV_URL di bawah.
   3) Kolom yang WAJIB ada di sheet (nama header harus sama persis):
      Tanggal | Regional | Branch | BD | Seller | Service | Shipment | Revenue |
      Target Shipment | Target Revenue | Status Seller | New Seller | Lost Seller |
      Achievement | Growth
   Tidak perlu mengubah kode lain — dashboard otomatis menyesuaikan.
   ========================================================================== */
const CONFIG = {
  SHEET_CSV_URL: "PASTE_GOOGLE_SHEET_CSV_URL_DISINI",
  REFRESH_INTERVAL_MS: 5 * 60 * 1000, // 5 menit
  DEFAULT_TARGET_ACHIEVEMENT: 100,
  ROWS_PER_PAGE: 12,
  COLORS: {
    purple: "#5E2B97",
    purpleDark: "#431E6E",
    purpleLight: "#8B5FC4",
    purpleTint: "#F1EBFA",
    yellow: "#FFC72C",
    yellowDark: "#E6AC00",
    success: "#1E9E62",
    danger: "#D0334C",
    grayLine: "#E2E4EC",
    palette: ["#5E2B97", "#FFC72C", "#8B5FC4", "#E6AC00", "#B48ADB", "#43306E", "#D9B3F0", "#7A4FBF"]
  }
};

Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.color = "#6B7280";
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.labels.boxWidth = 8;

/* ==========================================================================
   2. STATE
   ========================================================================== */
const STATE = {
  rawData: [],       // seluruh data hasil load
  filteredData: [],  // data setelah filter
  filters: { dateFrom: "", dateTo: "", month: "", regional: "", branch: "", bd: "", channel: "", service: "", seller: "" },
  charts: {},         // registry instance Chart.js
  table: { page: 1, sortKey: "Tanggal", sortDir: "desc", search: "" },
  countdownSec: CONFIG.REFRESH_INTERVAL_MS / 1000,
  refreshTimer: null,
  countdownTimer: null
};

/* ==========================================================================
   3. UTILS
   ========================================================================== */
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

function fmtNum(n) {
  if (n === null || n === undefined || isNaN(n)) return "-";
  return Math.round(n).toLocaleString("id-ID");
}
function fmtCurrency(n) {
  if (n === null || n === undefined || isNaN(n)) return "-";
  return "Rp " + Math.round(n).toLocaleString("id-ID");
}
function fmtCurrencyShort(n) {
  if (n === null || n === undefined || isNaN(n)) return "-";
  const abs = Math.abs(n);
  if (abs >= 1e9) return "Rp " + (n / 1e9).toFixed(1) + " M";
  if (abs >= 1e6) return "Rp " + (n / 1e6).toFixed(1) + " Jt";
  if (abs >= 1e3) return "Rp " + (n / 1e3).toFixed(0) + " Rb";
  return "Rp " + Math.round(n);
}
function fmtDate(d) {
  if (!(d instanceof Date) || isNaN(d)) return "-";
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
}
function isoDate(d) {
  return d.toISOString().slice(0, 10);
}
function parseDateLoose(v) {
  if (v instanceof Date) return v;
  if (!v) return null;
  const s = String(v).trim();
  // format dd/mm/yyyy
  let m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
  // format yyyy-mm-dd
  m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
  const d = new Date(s);
  return isNaN(d) ? null : d;
}
function debounce(fn, wait) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}
function groupSum(arr, keyFn, valFn) {
  const map = new Map();
  arr.forEach((row) => {
    const k = keyFn(row);
    map.set(k, (map.get(k) || 0) + (valFn(row) || 0));
  });
  return map;
}
function topNFromMap(map, n, desc = true) {
  return Array.from(map.entries())
    .sort((a, b) => (desc ? b[1] - a[1] : a[1] - b[1]))
    .slice(0, n);
}
function linearForecast(seriesY, stepsAhead) {
  const n = seriesY.length;
  const xs = seriesY.map((_, i) => i);
  const xMean = xs.reduce((a, b) => a + b, 0) / n;
  const yMean = seriesY.reduce((a, b) => a + b, 0) / n;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) { num += (xs[i] - xMean) * (seriesY[i] - yMean); den += (xs[i] - xMean) ** 2; }
  const slope = den === 0 ? 0 : num / den;
  const intercept = yMean - slope * xMean;
  const out = [];
  for (let s = 1; s <= stepsAhead; s++) {
    const val = intercept + slope * (n - 1 + s);
    out.push(Math.max(0, val));
  }
  return out;
}
function seededRandom(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => (s = (s * 16807) % 2147483647) / 2147483647;
}
function heatColor(pct) {
  // pct 0..130 -> gradasi merah->kuning->ungu (rendah ke tinggi)
  if (pct >= 105) return CONFIG.COLORS.purple;
  if (pct >= 95) return CONFIG.COLORS.purpleLight;
  if (pct >= 85) return CONFIG.COLORS.yellow;
  if (pct >= 70) return CONFIG.COLORS.yellowDark;
  return CONFIG.COLORS.danger;
}

/* ==========================================================================
   4. DATA LOADING
   ========================================================================== */
function loadData() {
  return new Promise((resolve) => {
    const url = CONFIG.SHEET_CSV_URL;
    const isPlaceholder = !url || url.includes("PASTE_GOOGLE_SHEET_CSV_URL_DISINI");
    if (isPlaceholder) {
      console.info("[Dashboard] SHEET_CSV_URL belum diatur — menggunakan data simulasi demo.");
      resolve(generateMockData());
      return;
    }
    Papa.parse(url, {
      download: true,
      header: true,
      skipEmptyLines: true,
      complete: (res) => {
        if (!res.data || !res.data.length) {
          console.warn("[Dashboard] Sheet kosong / gagal parse, fallback ke data demo.");
          resolve(generateMockData());
        } else {
          resolve(res.data.map(normalizeRow).filter(Boolean));
        }
      },
      error: (err) => {
        console.error("[Dashboard] Gagal memuat CSV Google Sheets:", err);
        resolve(generateMockData());
      }
    });
  });
}

function normalizeRow(r) {
  const tanggal = parseDateLoose(r["Tanggal"]);
  if (!tanggal) return null;
  const shipment = parseFloat(r["Shipment"]) || 0;
  const revenue = parseFloat(r["Revenue"]) || 0;
  const targetShipment = parseFloat(r["Target Shipment"]) || 0;
  const targetRevenue = parseFloat(r["Target Revenue"]) || 0;
  const achievement = r["Achievement"] ? parseFloat(r["Achievement"]) : (targetShipment ? (shipment / targetShipment) * 100 : 0);
  const growth = r["Growth"] ? parseFloat(r["Growth"]) : 0;
  return {
    Tanggal: tanggal,
    Regional: (r["Regional"] || "").trim() || "Unknown",
    Branch: (r["Branch"] || "").trim() || "Unknown",
    BD: (r["BD"] || "").trim() || "Unknown",
    Seller: (r["Seller"] || "").trim() || "Unknown",
    Service: (r["Service"] || "").trim() || "Unknown",
    Channel: (r["Channel"] || inferChannel(r["Service"])).trim(),
    Shipment: shipment,
    Revenue: revenue,
    TargetShipment: targetShipment,
    TargetRevenue: targetRevenue,
    StatusSeller: (r["Status Seller"] || "Active").trim(),
    NewSeller: /^(y|yes|true|1)$/i.test(String(r["New Seller"] || "").trim()),
    LostSeller: /^(y|yes|true|1)$/i.test(String(r["Lost Seller"] || "").trim()),
    Achievement: achievement,
    Growth: growth
  };
}
function inferChannel(service) {
  const s = (service || "").toLowerCase();
  if (s.includes("instant") || s.includes("same")) return "Retail";
  if (s.includes("cargo")) return "Corporate";
  return "Marketplace";
}

/* -------- Data simulasi (dipakai bila SHEET_CSV_URL belum diisi) -------- */
function generateMockData() {
  const rng = seededRandom(20260717);
  const regions = {
    "Jabodetabek": ["Jakarta Pusat", "Jakarta Selatan", "Tangerang"],
    "Jawa Barat": ["Bandung", "Bekasi"],
    "Jawa Timur": ["Surabaya", "Malang"],
    "Sumatra": ["Medan", "Palembang"]
  };
  const services = ["Same Day", "Next Day", "Regular", "Instant", "Cargo"];
  const unitPrice = { "Same Day": 22000, "Next Day": 17000, "Regular": 12000, "Instant": 28000, "Cargo": 35000 };

  const branches = [];
  Object.entries(regions).forEach(([regional, list]) => list.forEach((b) => branches.push({ regional, branch: b })));

  // buat daftar BD & Seller
  const bds = [];
  branches.forEach((b) => {
    const bdCount = 2;
    for (let i = 1; i <= bdCount; i++) bds.push({ ...b, bd: `BD ${b.branch.split(" ")[0]}-${i}` });
  });
  const sellers = [];
  bds.forEach((bd) => {
    const sellerCount = 4 + Math.floor(rng() * 3);
    for (let i = 1; i <= sellerCount; i++) {
      sellers.push({
        ...bd,
        seller: `Seller-${bd.bd.replace(/\s/g, "")}-${i}`,
        service: services[Math.floor(rng() * services.length)],
        baseline: 8 + rng() * 40,
        startDay: Math.floor(rng() * 55),
        churns: rng() < 0.18
      });
    }
  });
  sellers.forEach((s) => { s.churnDay = s.churns ? s.startDay + 20 + Math.floor(rng() * 35) : null; });

  const totalDays = 90;
  const today = new Date(2026, 6, 17); // 17 Juli 2026
  const startDate = new Date(today); startDate.setDate(today.getDate() - (totalDays - 1));

  const rows = [];
  sellers.forEach((s) => {
    let prevShipment = null;
    const lastDay = s.churnDay ? Math.min(s.churnDay, totalDays - 1) : totalDays - 1;
    for (let d = s.startDay; d <= lastDay; d++) {
      if (rng() < 0.12) continue; // hari tanpa transaksi
      const date = new Date(startDate); date.setDate(startDate.getDate() + d);
      const weekday = date.getDay(); // 0 minggu
      const weekendFactor = (weekday === 0) ? 0.55 : (weekday === 6 ? 0.8 : 1);
      const trend = 1 + (d / totalDays) * 0.25;
      const noise = 0.75 + rng() * 0.5;
      const shipment = Math.max(0, Math.round(s.baseline * weekendFactor * trend * noise));
      const price = unitPrice[s.service] * (0.9 + rng() * 0.2);
      const revenue = Math.round(shipment * price);
      const targetShipment = Math.round(s.baseline * 1.08);
      const targetRevenue = Math.round(targetShipment * unitPrice[s.service]);
      const achievement = targetShipment ? (shipment / targetShipment) * 100 : 0;
      const growth = prevShipment ? ((shipment - prevShipment) / prevShipment) * 100 : 0;
      const isLastDay = d === lastDay && s.churns;
      rows.push({
        Tanggal: date,
        Regional: s.regional,
        Branch: s.branch,
        BD: s.bd,
        Seller: s.seller,
        Service: s.service,
        Channel: inferChannel(s.service),
        Shipment: shipment,
        Revenue: revenue,
        TargetShipment: targetShipment,
        TargetRevenue: targetRevenue,
        StatusSeller: isLastDay ? "Inactive" : "Active",
        NewSeller: d === s.startDay,
        LostSeller: isLastDay,
        Achievement: achievement,
        Growth: growth
      });
      prevShipment = shipment;
    }
  });
  return rows;
}

/* ==========================================================================
   5. FILTERS (cascading)
   ========================================================================== */
function uniqueSorted(arr) { return Array.from(new Set(arr)).sort((a, b) => String(a).localeCompare(String(b))); }

function applyFiltersExcept(data, exclude) {
  const f = STATE.filters;
  return data.filter((r) => {
    if (exclude !== "dateFrom" && f.dateFrom && r.Tanggal < new Date(f.dateFrom)) return false;
    if (exclude !== "dateTo" && f.dateTo && r.Tanggal > new Date(f.dateTo)) return false;
    if (exclude !== "month" && f.month && `${r.Tanggal.getFullYear()}-${String(r.Tanggal.getMonth() + 1).padStart(2, "0")}` !== f.month) return false;
    if (exclude !== "regional" && f.regional && r.Regional !== f.regional) return false;
    if (exclude !== "branch" && f.branch && r.Branch !== f.branch) return false;
    if (exclude !== "bd" && f.bd && r.BD !== f.bd) return false;
    if (exclude !== "channel" && f.channel && r.Channel !== f.channel) return false;
    if (exclude !== "service" && f.service && r.Service !== f.service) return false;
    if (exclude !== "seller" && f.seller && r.Seller !== f.seller) return false;
    return true;
  });
}
function getFilteredData() { return applyFiltersExcept(STATE.rawData, null); }

function populateSelect(id, values, formatter) {
  const el = $(id);
  const current = el.value;
  const placeholder = el.querySelector('option[value=""]');
  el.innerHTML = "";
  if (placeholder) el.appendChild(placeholder);
  values.forEach((v) => {
    const opt = document.createElement("option");
    opt.value = v; opt.textContent = formatter ? formatter(v) : v;
    el.appendChild(opt);
  });
  if (values.includes(current)) el.value = current;
}

function refreshFilterOptions() {
  const dates = uniqueSorted(STATE.rawData.map((r) => isoDate(r.Tanggal)));
  populateSelect("#fDateFrom", dates);
  populateSelect("#fDateTo", dates);
  if (!STATE.filters.dateFrom && dates.length) { STATE.filters.dateFrom = dates[0]; $("#fDateFrom").value = dates[0]; }
  if (!STATE.filters.dateTo && dates.length) { STATE.filters.dateTo = dates[dates.length - 1]; $("#fDateTo").value = dates[dates.length - 1]; }

  const months = uniqueSorted(STATE.rawData.map((r) => `${r.Tanggal.getFullYear()}-${String(r.Tanggal.getMonth() + 1).padStart(2, "0")}`));
  populateSelect("#fMonth", months, (m) => new Date(m + "-01").toLocaleDateString("id-ID", { month: "long", year: "numeric" }));

  populateSelect("#fRegional", uniqueSorted(applyFiltersExcept(STATE.rawData, "regional").map((r) => r.Regional)));
  populateSelect("#fBranch", uniqueSorted(applyFiltersExcept(STATE.rawData, "branch").map((r) => r.Branch)));
  populateSelect("#fBD", uniqueSorted(applyFiltersExcept(STATE.rawData, "bd").map((r) => r.BD)));
  populateSelect("#fChannel", uniqueSorted(applyFiltersExcept(STATE.rawData, "channel").map((r) => r.Channel)));
  populateSelect("#fService", uniqueSorted(applyFiltersExcept(STATE.rawData, "service").map((r) => r.Service)));
  populateSelect("#fSeller", uniqueSorted(applyFiltersExcept(STATE.rawData, "seller").map((r) => r.Seller)));
}

function bindFilterEvents() {
  const map = { fDateFrom: "dateFrom", fDateTo: "dateTo", fMonth: "month", fRegional: "regional", fBranch: "branch", fBD: "bd", fChannel: "channel", fService: "service", fSeller: "seller" };
  Object.entries(map).forEach(([id, key]) => {
    $("#" + id).addEventListener("change", (e) => {
      STATE.filters[key] = e.target.value;
      refreshFilterOptions();
      renderAll();
    });
  });
  $("#resetFilters").addEventListener("click", () => {
    Object.keys(STATE.filters).forEach((k) => (STATE.filters[k] = ""));
    refreshFilterOptions();
    renderAll();
  });
}

/* ==========================================================================
   6. KPI
   ========================================================================== */
const KPI_ICONS = {
  box: '<path d="M12 2 3 7v10l9 5 9-5V7l-9-5Zm0 2.3 6.6 3.7L12 12l-6.6-4L12 4.3ZM5 9.2l6 3.5v7.1l-6-3.3V9.2Zm8 10.6v-7.1l6-3.5v7.3l-6 3.3Z"/>',
  money: '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 15.9v1.1h-2v-1.1c-1.6-.3-2.7-1.3-2.9-2.8h1.9c.1.7.7 1.2 1.9 1.2 1.1 0 1.8-.5 1.8-1.2 0-.7-.5-1-2-1.4-1.9-.5-3.3-1.1-3.3-3 0-1.4 1.1-2.4 2.6-2.7V7h2v1c1.4.3 2.4 1.2 2.6 2.6h-1.9c-.1-.6-.6-1-1.6-1-1 0-1.6.4-1.6 1s.6.9 2 1.3c2 .5 3.3 1.2 3.3 3.1 0 1.5-1.1 2.5-2.8 2.9Z"/>',
  users: '<path d="M16 11c1.7 0 3-1.3 3-3s-1.3-3-3-3-3 1.3-3 3 1.3 3 3 3Zm-8 0c1.7 0 3-1.3 3-3S9.7 5 8 5 5 6.3 5 8s1.3 3 3 3Zm0 2c-2.3 0-7 1.2-7 3.5V19h9v-2.5c0-1 .4-2 1.1-2.8C10 13.3 8.7 13 8 13Zm8 0c-.4 0-.8 0-1.3.1.8.9 1.3 2 1.3 3.4V19h7v-2.5c0-2.3-4.7-3.5-7-3.5Z"/>',
  chartAvg: '<path d="M3 3h2v18H3V3Zm4 10h2v8H7v-8Zm4-6h2v14h-2V7Zm4 3h2v11h-2V10Zm4-7h2v18h-2V3Z"/>',
  target: '<path d="M12 2a10 10 0 1 0 .001 20A10 10 0 0 0 12 2Zm0 16a6 6 0 1 1 0-12 6 6 0 0 1 0 12Zm0-9a3 3 0 1 0 .001 6A3 3 0 0 0 12 9Z"/>',
  trend: '<path d="M3 17 9 11l4 4 8-9 1.4 1.4L14 19l-4-4-6 6L3 17Z"/>',
  userPlus: '<path d="M10 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 8c0-2.7 4.7-4 7-4s7 1.3 7 4v1H3v-1Zm16-9h2v3h3v2h-3v3h-2v-3h-3v-2h3v-3Z"/>',
  userMinus: '<path d="M10 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 8c0-2.7 4.7-4 7-4s7 1.3 7 4v1H3v-1Zm13-6h6v2h-6v-2Z"/>'
};

function computeKPIs(data) {
  const totalShipment = data.reduce((a, r) => a + r.Shipment, 0);
  const totalRevenue = data.reduce((a, r) => a + r.Revenue, 0);
  const totalTargetShipment = data.reduce((a, r) => a + r.TargetShipment, 0);
  const activeSellers = new Set(data.filter((r) => r.StatusSeller === "Active").map((r) => r.Seller));
  const allSellers = new Set(data.map((r) => r.Seller));
  const avgShipmentPerSeller = allSellers.size ? totalShipment / allSellers.size : 0;
  const achievementPct = totalTargetShipment ? (totalShipment / totalTargetShipment) * 100 : 0;
  const newSellerCount = new Set(data.filter((r) => r.NewSeller).map((r) => r.Seller)).size;
  const churnSellerCount = new Set(data.filter((r) => r.LostSeller).map((r) => r.Seller)).size;

  // growth vs kemarin & vs bulan lalu dihitung dari seluruh rawData (tidak dibatasi filter tanggal agar comparable)
  const dates = uniqueSorted(data.map((r) => isoDate(r.Tanggal)));
  const lastDate = dates[dates.length - 1];
  let growthYesterday = 0;
  if (lastDate) {
    const lastD = new Date(lastDate);
    const prevD = new Date(lastD); prevD.setDate(lastD.getDate() - 1);
    const lastTotal = data.filter((r) => isoDate(r.Tanggal) === isoDate(lastD)).reduce((a, r) => a + r.Shipment, 0);
    const prevTotal = data.filter((r) => isoDate(r.Tanggal) === isoDate(prevD)).reduce((a, r) => a + r.Shipment, 0);
    growthYesterday = prevTotal ? ((lastTotal - prevTotal) / prevTotal) * 100 : 0;
  }
  let growthMonth = 0;
  if (lastDate) {
    const lastD = new Date(lastDate);
    const curMonthStart = new Date(lastD.getFullYear(), lastD.getMonth(), 1);
    const prevMonthStart = new Date(lastD.getFullYear(), lastD.getMonth() - 1, 1);
    const prevMonthSameDay = new Date(lastD.getFullYear(), lastD.getMonth() - 1, lastD.getDate());
    const curTotal = data.filter((r) => r.Tanggal >= curMonthStart && r.Tanggal <= lastD).reduce((a, r) => a + r.Shipment, 0);
    const prevTotal = data.filter((r) => r.Tanggal >= prevMonthStart && r.Tanggal <= prevMonthSameDay).reduce((a, r) => a + r.Shipment, 0);
    growthMonth = prevTotal ? ((curTotal - prevTotal) / prevTotal) * 100 : 0;
  }

  return { totalShipment, totalRevenue, activeSellerCount: activeSellers.size, avgShipmentPerSeller, achievementPct, growthYesterday, growthMonth, newSellerCount, churnSellerCount };
}

function deltaHtml(val, suffix = "%") {
  const cls = val > 0.01 ? "up" : val < -0.01 ? "down" : "flat";
  const arrow = val > 0.01 ? "▲" : val < -0.01 ? "▼" : "▬";
  return `<div class="kpi-card__delta ${cls}">${arrow} ${Math.abs(val).toFixed(1)}${suffix}</div>`;
}

function renderKPIs(k) {
  const cards = [
    { label: "Total Shipment", value: fmtNum(k.totalShipment), icon: KPI_ICONS.box, delta: deltaHtml(k.growthYesterday) },
    { label: "Total Revenue", value: fmtCurrencyShort(k.totalRevenue), icon: KPI_ICONS.money, delta: deltaHtml(k.growthMonth) },
    { label: "Seller Active", value: fmtNum(k.activeSellerCount), icon: KPI_ICONS.users, delta: "" },
    { label: "Avg Shipment / Seller", value: fmtNum(k.avgShipmentPerSeller), icon: KPI_ICONS.chartAvg, delta: "" },
    { label: "Achievement Target", value: k.achievementPct.toFixed(1) + "%", icon: KPI_ICONS.target, delta: deltaHtml(k.achievementPct - CONFIG.DEFAULT_TARGET_ACHIEVEMENT) },
    { label: "Growth vs Yesterday", value: (k.growthYesterday >= 0 ? "+" : "") + k.growthYesterday.toFixed(1) + "%", icon: KPI_ICONS.trend, delta: deltaHtml(k.growthYesterday) },
    { label: "Growth vs Last Month", value: (k.growthMonth >= 0 ? "+" : "") + k.growthMonth.toFixed(1) + "%", icon: KPI_ICONS.trend, delta: deltaHtml(k.growthMonth) },
    { label: "New Seller", value: fmtNum(k.newSellerCount), icon: KPI_ICONS.userPlus, delta: "" },
    { label: "Churn Seller", value: fmtNum(k.churnSellerCount), icon: KPI_ICONS.userMinus, delta: "" }
  ];
  $("#kpiGrid").innerHTML = cards.map((c) => `
    <div class="kpi-card">
      <div class="kpi-card__top">
        <div class="kpi-card__icon"><svg viewBox="0 0 24 24">${c.icon}</svg></div>
      </div>
      <div class="kpi-card__label">${c.label}</div>
      <div class="kpi-card__value">${c.value}</div>
      ${c.delta}
    </div>`).join("");
}

/* ==========================================================================
   7. ALERTS
   ========================================================================== */
function computeAlerts(data, kpi) {
  const alerts = [];
  if (kpi.growthYesterday <= -20) alerts.push({ level: "danger", text: `Shipment turun ${Math.abs(kpi.growthYesterday).toFixed(1)}% dibanding kemarin.` });
  const revToday = data.filter(r=>isoDate(r.Tanggal)===uniqueSorted(data.map(r=>isoDate(r.Tanggal))).slice(-1)[0]).reduce((a,r)=>a+r.Revenue,0);
  const dates = uniqueSorted(data.map(r=>isoDate(r.Tanggal)));
  if (dates.length>=2){
    const prevDate = dates[dates.length-2];
    const revPrev = data.filter(r=>isoDate(r.Tanggal)===prevDate).reduce((a,r)=>a+r.Revenue,0);
    const revChange = revPrev ? ((revToday-revPrev)/revPrev)*100 : 0;
    if (revChange <= -20) alerts.push({ level:"danger", text:`Revenue turun ${Math.abs(revChange).toFixed(1)}% dibanding hari sebelumnya.`});
  }
  if (kpi.achievementPct < 100) alerts.push({ level: "warn", text: `Target belum tercapai — Achievement saat ini ${kpi.achievementPct.toFixed(1)}%.` });
  if (kpi.growthMonth < 0) alerts.push({ level: "warn", text: `Growth vs bulan lalu negatif (${kpi.growthMonth.toFixed(1)}%).` });

  // seller inactive > 7 hari (tidak ada transaksi sejak > 7 hari dari tanggal terakhir dataset)
  const lastGlobalDate = uniqueSorted(STATE.rawData.map((r) => isoDate(r.Tanggal))).slice(-1)[0];
  if (lastGlobalDate) {
    const lastDateObj = new Date(lastGlobalDate);
    const lastTxBySeller = new Map();
    STATE.rawData.forEach((r) => {
      const cur = lastTxBySeller.get(r.Seller);
      if (!cur || r.Tanggal > cur) lastTxBySeller.set(r.Seller, r.Tanggal);
    });
    let inactiveCount = 0;
    lastTxBySeller.forEach((d) => { if ((lastDateObj - d) / 86400000 > 7) inactiveCount++; });
    if (inactiveCount > 0) alerts.push({ level: "warn", text: `${inactiveCount} seller tidak ada transaksi lebih dari 7 hari.` });
  }
  return alerts;
}
function renderAlerts(alerts) {
  const wrap = $("#alertsWrap");
  if (!alerts.length) { wrap.hidden = true; return; }
  wrap.hidden = false;
  $("#alertsList").innerHTML = alerts.map((a) => `<div class="alert-item ${a.level === "warn" ? "warn" : ""}">${a.text}</div>`).join("");
}

/* ==========================================================================
   8. AI INSIGHT (rule-based narrative engine)
   ========================================================================== */
function generateInsights(data, kpi) {
  if (!data.length) return "<p>Tidak ada data pada filter saat ini.</p>";
  const byBranch = groupSum(data, (r) => r.Branch, (r) => r.Shipment);
  const byBranchRev = groupSum(data, (r) => r.Branch, (r) => r.Revenue);
  const bySeller = groupSum(data, (r) => r.Seller, (r) => r.Shipment);
  const bestBranch = topNFromMap(byBranch, 1)[0];
  const worstBranch = topNFromMap(byBranch, 1, false)[0];
  const bestSeller = topNFromMap(bySeller, 1)[0];

  // seller yang mulai turun: bandingkan shipment 7 hari terakhir vs 7 hari sebelumnya per seller
  const dates = uniqueSorted(data.map((r) => isoDate(r.Tanggal)));
  const lastDate = dates[dates.length - 1] ? new Date(dates[dates.length - 1]) : null;
  let decliningSeller = null;
  if (lastDate) {
    const d7 = new Date(lastDate); d7.setDate(lastDate.getDate() - 6);
    const d14 = new Date(lastDate); d14.setDate(lastDate.getDate() - 13);
    const d8 = new Date(lastDate); d8.setDate(lastDate.getDate() - 7);
    const recent = groupSum(data.filter((r) => r.Tanggal >= d7 && r.Tanggal <= lastDate), (r) => r.Seller, (r) => r.Shipment);
    const prior = groupSum(data.filter((r) => r.Tanggal >= d14 && r.Tanggal <= d8), (r) => r.Seller, (r) => r.Shipment);
    let worstDrop = 0;
    prior.forEach((v, k) => {
      const rec = recent.get(k) || 0;
      const drop = v ? ((rec - v) / v) * 100 : 0;
      if (drop < worstDrop) { worstDrop = drop; decliningSeller = k; }
    });
  }

  const shipDir = kpi.growthYesterday >= 0 ? "naik" : "turun";
  const revShare = byBranchRev.get(bestBranch?.[0]) || 0;
  const totalRev = kpi.totalRevenue || 1;

  const points = [];
  points.push(`Shipment ${shipDir} <b>${Math.abs(kpi.growthYesterday).toFixed(1)}%</b> dibanding kemarin, didorong oleh performa branch <b>${bestBranch ? bestBranch[0] : "-"}</b> yang berkontribusi ${bestBranch ? fmtNum(bestBranch[1]) : 0} shipment.`);
  points.push(`Revenue tumbuh <b>${kpi.growthMonth >= 0 ? "+" : ""}${kpi.growthMonth.toFixed(1)}%</b> dibanding periode bulan lalu, dengan kontribusi terbesar dari branch <b>${bestBranch ? bestBranch[0] : "-"}</b> (${((revShare / totalRev) * 100).toFixed(1)}% dari total revenue).`);
  points.push(`Branch terbaik saat ini adalah <b>${bestBranch ? bestBranch[0] : "-"}</b>, sementara branch <b>${worstBranch ? worstBranch[0] : "-"}</b> perlu perhatian karena volume shipment paling rendah.`);
  points.push(`Seller dengan performa terbaik adalah <b>${bestSeller ? bestSeller[0] : "-"}</b> dengan total ${bestSeller ? fmtNum(bestSeller[1]) : 0} shipment.`);
  if (decliningSeller) points.push(`Seller <b>${decliningSeller}</b> menunjukkan tren penurunan shipment dalam 7 hari terakhir dan berisiko churn.`);
  if (kpi.achievementPct < 100) points.push(`Rekomendasi aksi: fokuskan effort BD pada branch dengan achievement terendah dan lakukan re-engagement untuk seller yang menurun agar target ${CONFIG.DEFAULT_TARGET_ACHIEVEMENT}% tercapai.`);
  else points.push(`Rekomendasi aksi: pertahankan momentum dengan replikasi strategi branch terbaik ke branch lain, serta perkuat program retensi seller.`);

  return `<ul>${points.map((p) => `<li>${p}</li>`).join("")}</ul>`;
}

/* ==========================================================================
   9. RANKING (Top10 / Bottom10)
   ========================================================================== */
function renderRankingCard(title, entries, formatter, bottom = false) {
  return `<div class="ranking-card ${bottom ? "ranking-card--bottom" : ""}">
    <h4>${title}</h4>
    ${entries.length ? entries.map((e, i) => `
      <div class="ranking-row">
        <div class="ranking-row__rank">${i + 1}</div>
        <div class="ranking-row__name" title="${e[0]}">${e[0]}</div>
        <div class="ranking-row__val">${formatter(e[1])}</div>
      </div>`).join("") : '<div class="ranking-row">Tidak ada data</div>'}
  </div>`;
}
function renderRankings(data) {
  const byBranch = groupSum(data, (r) => r.Branch, (r) => r.Shipment);
  const byBD = groupSum(data, (r) => r.BD, (r) => r.Shipment);
  const bySeller = groupSum(data, (r) => r.Seller, (r) => r.Shipment);
  const html = [
    renderRankingCard("🏆 Top 10 Branch", topNFromMap(byBranch, 10), fmtNum),
    renderRankingCard("🏆 Top 10 BD", topNFromMap(byBD, 10), fmtNum),
    renderRankingCard("🏆 Top 10 Seller", topNFromMap(bySeller, 10), fmtNum),
    renderRankingCard("🔻 Bottom 10 Branch", topNFromMap(byBranch, 10, false), fmtNum, true),
    renderRankingCard("🔻 Bottom 10 Seller", topNFromMap(bySeller, 10, false), fmtNum, true),
    renderRankingCard("🔻 Bottom 10 BD", topNFromMap(byBD, 10, false), fmtNum, true)
  ].join("");
  $("#rankingGrid").innerHTML = html;
}

/* ==========================================================================
   10. CHARTS
   ========================================================================== */
function upsertChart(id, config) {
  const canvas = document.getElementById(id);
  if (!canvas) return;
  if (STATE.charts[id]) STATE.charts[id].destroy();
  STATE.charts[id] = new Chart(canvas.getContext("2d"), config);
  canvas.closest(".chart-card").classList.remove("chart-refresh");
  void canvas.offsetWidth;
  canvas.closest(".chart-card").classList.add("chart-refresh");
}
const C = CONFIG.COLORS;
const baseGrid = { grid: { color: "#F0F0F5" }, ticks: { font: { size: 10 } } };

function seriesByDate(data, valFn) {
  const map = groupSum(data, (r) => isoDate(r.Tanggal), valFn);
  const dates = uniqueSorted(Array.from(map.keys()));
  return { labels: dates.map((d) => new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })), values: dates.map((d) => map.get(d) || 0), rawDates: dates };
}

function renderAllCharts(data) {
  renderShipmentTrend(data);
  renderRevenueTrend(data);
  renderShipmentBranch(data);
  renderRevenueBranch(data);
  renderTopSeller(data);
  renderDonutService(data);
  renderGauge(data);
  renderHourly(data);
  renderRevenueContribution(data);
  renderNewLostSellerTrend(data);
  renderSellerClassification(data);
  renderPareto(data);
  renderFunnel(data);
  renderHeatmap(data);
  renderLeaderboards(data);
  renderForecasts(data);
}

function renderShipmentTrend(data) {
  const s = seriesByDate(data, (r) => r.Shipment);
  upsertChart("chartShipmentTrend", {
    type: "line",
    data: { labels: s.labels, datasets: [{ label: "Shipment", data: s.values, borderColor: C.purple, backgroundColor: "rgba(94,43,151,.08)", tension: .35, pointRadius: 2, fill: false, borderWidth: 2.5 }] },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: baseGrid, x: { grid: { display: false }, ticks: { font: { size: 10 }, maxTicksLimit: 10 } } }, plugins: { legend: { display: false } } }
  });
}
function renderRevenueTrend(data) {
  const s = seriesByDate(data, (r) => r.Revenue);
  upsertChart("chartRevenueTrend", {
    type: "line",
    data: { labels: s.labels, datasets: [{ label: "Revenue", data: s.values, borderColor: C.yellowDark, backgroundColor: "rgba(255,199,44,.28)", tension: .35, pointRadius: 0, fill: true, borderWidth: 2.5 }] },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { ...baseGrid, ticks: { callback: (v) => fmtCurrencyShort(v) } }, x: { grid: { display: false }, ticks: { font: { size: 10 }, maxTicksLimit: 10 } } }, plugins: { legend: { display: false } } }
  });
}
function renderShipmentBranch(data) {
  const m = groupSum(data, (r) => r.Branch, (r) => r.Shipment);
  const arr = topNFromMap(m, 15);
  upsertChart("chartShipmentBranch", {
    type: "bar",
    data: { labels: arr.map((a) => a[0]), datasets: [{ label: "Shipment", data: arr.map((a) => a[1]), backgroundColor: C.purple, borderRadius: 5 }] },
    options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: baseGrid, y: { grid: { display: false } } } }
  });
}
function renderRevenueBranch(data) {
  const m = groupSum(data, (r) => r.Branch, (r) => r.Revenue);
  const arr = topNFromMap(m, 15);
  upsertChart("chartRevenueBranch", {
    type: "bar",
    data: { labels: arr.map((a) => a[0]), datasets: [{ label: "Revenue", data: arr.map((a) => a[1]), backgroundColor: C.yellow, borderRadius: 5 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { ...baseGrid, ticks: { callback: (v) => fmtCurrencyShort(v) } }, x: { grid: { display: false }, ticks: { font: { size: 9 } } } } }
  });
}
function renderTopSeller(data) {
  const m = groupSum(data, (r) => r.Seller, (r) => r.Shipment);
  const arr = topNFromMap(m, 10);
  upsertChart("chartTopSeller", {
    type: "bar",
    data: { labels: arr.map((a) => a[0]), datasets: [{ data: arr.map((a) => a[1]), backgroundColor: C.purpleLight, borderRadius: 5 }] },
    options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: baseGrid, y: { grid: { display: false }, ticks: { font: { size: 10 } } } } }
  });
}
function renderDonutService(data) {
  const mShip = groupSum(data, (r) => r.Service, (r) => r.Shipment);
  const mRev = groupSum(data, (r) => r.Service, (r) => r.Revenue);
  const labels1 = Array.from(mShip.keys());
  upsertChart("chartShipmentService", {
    type: "doughnut",
    data: { labels: labels1, datasets: [{ data: labels1.map((l) => mShip.get(l)), backgroundColor: C.palette, borderWidth: 2, borderColor: "#fff" }] },
    options: { responsive: true, maintainAspectRatio: false, cutout: "62%", plugins: { legend: { position: "bottom", labels: { font: { size: 10 } } } } }
  });
  const labels2 = Array.from(mRev.keys());
  upsertChart("chartRevenueService", {
    type: "doughnut",
    data: { labels: labels2, datasets: [{ data: labels2.map((l) => mRev.get(l)), backgroundColor: C.palette, borderWidth: 2, borderColor: "#fff" }] },
    options: { responsive: true, maintainAspectRatio: false, cutout: "62%", plugins: { legend: { position: "bottom", labels: { font: { size: 10 } } } } }
  });
}
function renderGauge(data) {
  const totalShipment = data.reduce((a, r) => a + r.Shipment, 0);
  const totalTarget = data.reduce((a, r) => a + r.TargetShipment, 0);
  const pct = totalTarget ? Math.min(150, (totalShipment / totalTarget) * 100) : 0;
  $("#gaugeValue").textContent = pct.toFixed(1) + "%";
  upsertChart("chartGauge", {
    type: "doughnut",
    data: { datasets: [{ data: [Math.min(pct, 100), Math.max(0, 100 - pct)], backgroundColor: [pct >= 100 ? C.success : C.yellow, "#EDEEF3"], borderWidth: 0 }] },
    options: { responsive: true, maintainAspectRatio: false, circumference: 180, rotation: 270, cutout: "75%", plugins: { legend: { display: false }, tooltip: { enabled: false } } }
  });
}
function renderHourly(data) {
  // simulasi pola per-jam berdasarkan proporsi tetap (data sumber harian) untuk representasi rata-rata operasional
  const hourWeights = [0.01, 0.005, 0.005, 0.005, 0.01, 0.02, 0.04, 0.07, 0.09, 0.10, 0.09, 0.08, 0.07, 0.07, 0.08, 0.08, 0.07, 0.06, 0.05, 0.03, 0.02, 0.01, 0.01, 0.005];
  const total = data.reduce((a, r) => a + r.Shipment, 0);
  const days = uniqueSorted(data.map((r) => isoDate(r.Tanggal))).length || 1;
  const avgPerDay = total / days;
  upsertChart("chartHourly", {
    type: "bar",
    data: { labels: hourWeights.map((_, h) => h + ":00"), datasets: [{ data: hourWeights.map((w) => Math.round(w * avgPerDay)), backgroundColor: C.purpleLight, borderRadius: 4 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { font: { size: 8 }, maxTicksLimit: 12 } }, y: baseGrid } }
  });
}
function renderRevenueContribution(data) {
  const m = groupSum(data, (r) => r.Branch, (r) => r.Revenue);
  const arr = topNFromMap(m, 8);
  upsertChart("chartRevenueContribution", {
    type: "pie",
    data: { labels: arr.map((a) => a[0]), datasets: [{ data: arr.map((a) => a[1]), backgroundColor: C.palette, borderWidth: 2, borderColor: "#fff" }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom", labels: { font: { size: 9 } } } } }
  });
}
function renderNewLostSellerTrend(data) {
  const newMap = groupSum(data.filter((r) => r.NewSeller), (r) => isoDate(r.Tanggal), () => 1);
  const lostMap = groupSum(data.filter((r) => r.LostSeller), (r) => isoDate(r.Tanggal), () => 1);
  const allDates = uniqueSorted(data.map((r) => isoDate(r.Tanggal)));
  const labels = allDates.map((d) => new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short" }));
  upsertChart("chartNewSeller", {
    type: "bar",
    data: { labels, datasets: [{ label: "New Seller", data: allDates.map((d) => newMap.get(d) || 0), backgroundColor: C.success, borderRadius: 4 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 8, font: { size: 9 } } }, y: baseGrid } }
  });
  upsertChart("chartLostSeller", {
    type: "bar",
    data: { labels, datasets: [{ label: "Lost Seller", data: allDates.map((d) => lostMap.get(d) || 0), backgroundColor: C.danger, borderRadius: 4 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 8, font: { size: 9 } } }, y: baseGrid } }
  });
}
function renderSellerClassification(data) {
  const m = groupSum(data, (r) => r.Seller, (r) => r.Shipment);
  const vals = Array.from(m.values()).sort((a, b) => b - a);
  const p20 = vals[Math.floor(vals.length * 0.2)] || 0;
  const p60 = vals[Math.floor(vals.length * 0.6)] || 0;
  let gold = 0, silver = 0, bronze = 0;
  m.forEach((v) => { if (v >= p20) gold++; else if (v >= p60) silver++; else bronze++; });
  upsertChart("chartSellerClass", {
    type: "pie",
    data: { labels: ["Gold (Top 20%)", "Silver (Mid)", "Bronze (Growth)"], datasets: [{ data: [gold, silver, bronze], backgroundColor: [C.yellow, C.purpleLight, C.grayLine], borderWidth: 2, borderColor: "#fff" }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom", labels: { font: { size: 10 } } } } }
  });
}
function renderPareto(data) {
  const m = groupSum(data, (r) => r.Seller, (r) => r.Shipment);
  const sorted = topNFromMap(m, 20);
  const total = Array.from(m.values()).reduce((a, b) => a + b, 0) || 1;
  let cum = 0;
  const cumPct = sorted.map((s) => { cum += s[1]; return (cum / total) * 100; });
  upsertChart("chartPareto", {
    data: { labels: sorted.map((s) => s[0]), datasets: [
      { type: "bar", label: "Shipment", data: sorted.map((s) => s[1]), backgroundColor: C.purple, order: 2, yAxisID: "y" },
      { type: "line", label: "Kumulatif %", data: cumPct, borderColor: C.yellowDark, borderWidth: 2, pointRadius: 2, yAxisID: "y1", order: 1, tension: .3 }
    ] },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { ...baseGrid, position: "left" }, y1: { position: "right", min: 0, max: 100, grid: { drawOnChartArea: false }, ticks: { callback: (v) => v + "%" } }, x: { grid: { display: false }, ticks: { display: false } } }, plugins: { legend: { position: "bottom", labels: { font: { size: 10 } } } } }
  });
}
function renderFunnel(data) {
  const allSellers = new Set(data.map((r) => r.Seller)).size;
  const activeSellers = new Set(data.filter((r) => r.StatusSeller === "Active").map((r) => r.Seller)).size;
  const meetTarget = new Set(data.filter((r) => r.Achievement >= 100).map((r) => r.Seller)).size;
  const bySeller = groupSum(data, (r) => r.Seller, (r) => r.Shipment);
  const sortedVals = Array.from(bySeller.values()).sort((a, b) => b - a);
  const p20cut = sortedVals[Math.floor(sortedVals.length * 0.2)] || 0;
  const topPerformers = Array.from(bySeller.values()).filter((v) => v >= p20cut).length;
  const retained = allSellers - new Set(data.filter((r) => r.LostSeller).map((r) => r.Seller)).size;
  const stages = [
    { label: "Total Seller", val: allSellers },
    { label: "Active Seller", val: activeSellers },
    { label: "Achieve Target", val: meetTarget },
    { label: "Top Performer (20%)", val: topPerformers },
    { label: "Retained (No Churn)", val: retained }
  ];
  upsertChart("chartFunnel", {
    type: "bar",
    data: { labels: stages.map((s) => s.label), datasets: [{ data: stages.map((s) => s.val), backgroundColor: C.palette, borderRadius: 6 }] },
    options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: baseGrid, y: { grid: { display: false } } } }
  });
}
function renderHeatmap(data) {
  const days = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
  const regionals = uniqueSorted(data.map((r) => r.Regional));
  const wrap = $("#heatmapWrap");
  if (!regionals.length) { wrap.innerHTML = "<p style='font-size:12px;color:#6B7280;'>Tidak ada data</p>"; return; }
  let html = `<div class="heatmap-row"><div class="heatmap-row__label"></div>${days.map((d) => `<div class="heatmap-row__label" style="text-align:center">${d}</div>`).join("")}</div>`;
  regionals.forEach((reg) => {
    const cells = days.map((_, dayIdx) => {
      const rows = data.filter((r) => r.Regional === reg && r.Tanggal.getDay() === dayIdx);
      if (!rows.length) return `<div class="heatmap-cell" style="background:#EDEEF3;color:#9AA0AE;">-</div>`;
      const avgAch = rows.reduce((a, r) => a + r.Achievement, 0) / rows.length;
      return `<div class="heatmap-cell" style="background:${heatColor(avgAch)}">${avgAch.toFixed(0)}</div>`;
    }).join("");
    html += `<div class="heatmap-row"><div class="heatmap-row__label" title="${reg}">${reg}</div>${cells}</div>`;
  });
  html += `<div class="heatmap-legend">Rendah <span style="width:10px;height:10px;background:${C.danger};border-radius:2px;display:inline-block;"></span><span style="width:10px;height:10px;background:${C.yellowDark};border-radius:2px;display:inline-block;"></span><span style="width:10px;height:10px;background:${C.yellow};border-radius:2px;display:inline-block;"></span><span style="width:10px;height:10px;background:${C.purpleLight};border-radius:2px;display:inline-block;"></span><span style="width:10px;height:10px;background:${C.purple};border-radius:2px;display:inline-block;"></span> Tinggi (Achievement %)</div>`;
  wrap.innerHTML = html;
}
function renderLeaderboards(data) {
  const mBranch = groupSum(data, (r) => r.Branch, (r) => r.Revenue);
  const mBD = groupSum(data, (r) => r.BD, (r) => r.Revenue);
  const arrB = topNFromMap(mBranch, 10);
  const arrD = topNFromMap(mBD, 10);
  upsertChart("chartLeaderboardBranch", {
    type: "bar",
    data: { labels: arrB.map((a) => a[0]), datasets: [{ data: arrB.map((a) => a[1]), backgroundColor: C.purple, borderRadius: 5 }] },
    options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (ctx) => fmtCurrencyShort(ctx.raw) } } }, scales: { x: { ...baseGrid, ticks: { callback: (v) => fmtCurrencyShort(v) } }, y: { grid: { display: false }, ticks: { font: { size: 10 } } } } }
  });
  upsertChart("chartLeaderboardBD", {
    type: "bar",
    data: { labels: arrD.map((a) => a[0]), datasets: [{ data: arrD.map((a) => a[1]), backgroundColor: C.yellowDark, borderRadius: 5 }] },
    options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (ctx) => fmtCurrencyShort(ctx.raw) } } }, scales: { x: { ...baseGrid, ticks: { callback: (v) => fmtCurrencyShort(v) } }, y: { grid: { display: false }, ticks: { font: { size: 10 } } } } }
  });
}
function renderForecasts(data) {
  const shipSeries = seriesByDate(data, (r) => r.Shipment);
  const revSeries = seriesByDate(data, (r) => r.Revenue);
  const forecastShip = linearForecast(shipSeries.values, 30);
  const forecastRev = linearForecast(revSeries.values, 30);
  const futureLabels = Array.from({ length: 30 }, (_, i) => {
    const last = shipSeries.rawDates.length ? new Date(shipSeries.rawDates[shipSeries.rawDates.length - 1]) : new Date();
    const d = new Date(last); d.setDate(last.getDate() + i + 1);
    return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short" });
  });
  const allLabels = [...shipSeries.labels, ...futureLabels];
  upsertChart("chartForecastShipment", {
    type: "line",
    data: { labels: allLabels, datasets: [
      { label: "Aktual", data: [...shipSeries.values, ...Array(30).fill(null)], borderColor: C.purple, borderWidth: 2, pointRadius: 0, tension: .3 },
      { label: "Forecast", data: [...Array(shipSeries.values.length - 1).fill(null), shipSeries.values[shipSeries.values.length - 1], ...forecastShip], borderColor: C.yellowDark, borderDash: [5, 4], borderWidth: 2, pointRadius: 0, tension: .3 }
    ] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom", labels: { font: { size: 10 } } } }, scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 8, font: { size: 9 } } }, y: baseGrid } }
  });
  upsertChart("chartForecastRevenue", {
    type: "line",
    data: { labels: allLabels, datasets: [
      { label: "Aktual", data: [...revSeries.values, ...Array(30).fill(null)], borderColor: C.purpleLight, borderWidth: 2, pointRadius: 0, tension: .3 },
      { label: "Forecast", data: [...Array(revSeries.values.length - 1).fill(null), revSeries.values[revSeries.values.length - 1], ...forecastRev], borderColor: C.yellow, borderDash: [5, 4], borderWidth: 2, pointRadius: 0, tension: .3 }
    ] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom", labels: { font: { size: 10 } } } }, scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 8, font: { size: 9 } } }, y: { ...baseGrid, ticks: { callback: (v) => fmtCurrencyShort(v) } } } }
  });
}

/* ==========================================================================
   11. TABLE
   ========================================================================== */
function getTableRows(data) {
  let rows = data.map((r) => ({
    Tanggal: r.Tanggal, Regional: r.Regional, Branch: r.Branch, BD: r.BD, Seller: r.Seller, Service: r.Service,
    Shipment: r.Shipment, Revenue: r.Revenue, Achievement: r.Achievement, Growth: r.Growth, Status: r.StatusSeller
  }));
  const q = STATE.table.search.trim().toLowerCase();
  if (q) rows = rows.filter((r) => Object.values(r).some((v) => String(v).toLowerCase().includes(q)));
  const { sortKey, sortDir } = STATE.table;
  rows.sort((a, b) => {
    let av = a[sortKey], bv = b[sortKey];
    if (av instanceof Date) { av = av.getTime(); bv = bv.getTime(); }
    if (typeof av === "string") return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
    return sortDir === "asc" ? av - bv : bv - av;
  });
  return rows;
}
function renderTable(data) {
  const rows = getTableRows(data);
  const perPage = CONFIG.ROWS_PER_PAGE;
  const totalPages = Math.max(1, Math.ceil(rows.length / perPage));
  if (STATE.table.page > totalPages) STATE.table.page = totalPages;
  const startIdx = (STATE.table.page - 1) * perPage;
  const pageRows = rows.slice(startIdx, startIdx + perPage);

  $("#tableBody").innerHTML = pageRows.map((r) => `
    <tr>
      <td>${fmtDate(r.Tanggal)}</td>
      <td>${r.Regional}</td>
      <td>${r.Branch}</td>
      <td>${r.BD}</td>
      <td>${r.Seller}</td>
      <td>${r.Service}</td>
      <td>${fmtNum(r.Shipment)}</td>
      <td>${fmtCurrency(r.Revenue)}</td>
      <td>${r.Achievement.toFixed(1)}%</td>
      <td class="${r.Growth >= 0 ? "growth-pos" : "growth-neg"}">${r.Growth >= 0 ? "+" : ""}${r.Growth.toFixed(1)}%</td>
      <td><span class="status-pill ${r.Status === "Active" ? "active" : "inactive"}">${r.Status}</span></td>
    </tr>`).join("") || `<tr><td colspan="11" style="text-align:center;padding:20px;">Tidak ada data</td></tr>`;

  renderPagination(totalPages);
  STATE.table._exportRows = rows; // simpan untuk export (semua baris hasil filter+search, bukan hanya 1 halaman)
}
function renderPagination(totalPages) {
  const cur = STATE.table.page;
  let html = `<button ${cur === 1 ? "disabled" : ""} data-page="${cur - 1}">‹</button>`;
  const maxButtons = 7;
  let start = Math.max(1, cur - 3), end = Math.min(totalPages, start + maxButtons - 1);
  start = Math.max(1, end - maxButtons + 1);
  for (let p = start; p <= end; p++) html += `<button class="${p === cur ? "active" : ""}" data-page="${p}">${p}</button>`;
  html += `<button ${cur === totalPages ? "disabled" : ""} data-page="${cur + 1}">›</button>`;
  html += `<span style="margin-left:8px;color:#6B7280;">Halaman ${cur} / ${totalPages}</span>`;
  $("#pagination").innerHTML = html;
  $$("#pagination button[data-page]").forEach((btn) => btn.addEventListener("click", () => {
    STATE.table.page = parseInt(btn.dataset.page, 10);
    renderTable(STATE.filteredData);
  }));
}
function bindTableEvents() {
  $("#tableSearch").addEventListener("input", debounce((e) => {
    STATE.table.search = e.target.value; STATE.table.page = 1; renderTable(STATE.filteredData);
  }, 250));
  $$("#dataTable thead th").forEach((th) => th.addEventListener("click", () => {
    const key = th.dataset.key;
    if (STATE.table.sortKey === key) STATE.table.sortDir = STATE.table.sortDir === "asc" ? "desc" : "asc";
    else { STATE.table.sortKey = key; STATE.table.sortDir = "desc"; }
    renderTable(STATE.filteredData);
  }));
  $("#exportExcel").addEventListener("click", () => exportExcel(STATE.table._exportRows || []));
  $("#exportCSV").addEventListener("click", () => exportCSV(STATE.table._exportRows || []));
  $("#exportPDF").addEventListener("click", () => exportPDF(STATE.table._exportRows || []));
}
function rowsToPlain(rows) {
  return rows.map((r) => ({
    Tanggal: fmtDate(r.Tanggal), Regional: r.Regional, Branch: r.Branch, BD: r.BD, Seller: r.Seller, Service: r.Service,
    Shipment: r.Shipment, Revenue: r.Revenue, "Achievement (%)": r.Achievement.toFixed(1), "Growth (%)": r.Growth.toFixed(1), Status: r.Status
  }));
}
function exportExcel(rows) {
  const ws = XLSX.utils.json_to_sheet(rowsToPlain(rows));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Commercial Data");
  XLSX.writeFile(wb, `paxel-commercial-${isoDate(new Date())}.xlsx`);
}
function exportCSV(rows) {
  const csv = Papa.unparse(rowsToPlain(rows));
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `paxel-commercial-${isoDate(new Date())}.csv`;
  link.click();
}
function exportPDF(rows) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: "landscape" });
  doc.setFontSize(14);
  doc.text("Paxel Commercial Performance — Data Export", 14, 14);
  doc.autoTable({
    startY: 20,
    head: [["Tanggal", "Regional", "Branch", "BD", "Seller", "Service", "Shipment", "Revenue", "Achv%", "Growth%", "Status"]],
    body: rows.slice(0, 500).map((r) => [fmtDate(r.Tanggal), r.Regional, r.Branch, r.BD, r.Seller, r.Service, fmtNum(r.Shipment), fmtCurrency(r.Revenue), r.Achievement.toFixed(1), r.Growth.toFixed(1), r.Status]),
    styles: { fontSize: 7 },
    headStyles: { fillColor: [94, 43, 151] }
  });
  doc.save(`paxel-commercial-${isoDate(new Date())}.pdf`);
}

/* ==========================================================================
   12. MASTER RENDER + INIT + AUTO REFRESH
   ========================================================================== */
function renderAll() {
  STATE.filteredData = getFilteredData();
  const kpi = computeKPIs(STATE.filteredData);
  renderKPIs(kpi);
  renderAlerts(computeAlerts(STATE.filteredData, kpi));
  $("#insightBody").innerHTML = generateInsights(STATE.filteredData, kpi);
  renderRankings(STATE.filteredData);
  renderAllCharts(STATE.filteredData);
  STATE.table.page = 1;
  renderTable(STATE.filteredData);
}

function setLastUpdated() {
  $("#lastUpdated").textContent = new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

async function fullRefresh(showLoader = true) {
  if (showLoader) $("#loadingOverlay").classList.remove("hidden");
  const data = await loadData();
  STATE.rawData = data;
  refreshFilterOptions();
  renderAll();
  setLastUpdated();
  if (showLoader) $("#loadingOverlay").classList.add("hidden");
}

function startCountdown() {
  clearInterval(STATE.countdownTimer);
  STATE.countdownSec = CONFIG.REFRESH_INTERVAL_MS / 1000;
  STATE.countdownTimer = setInterval(() => {
    STATE.countdownSec--;
    if (STATE.countdownSec <= 0) STATE.countdownSec = CONFIG.REFRESH_INTERVAL_MS / 1000;
    const m = String(Math.floor(STATE.countdownSec / 60)).padStart(2, "0");
    const s = String(Math.floor(STATE.countdownSec % 60)).padStart(2, "0");
    $("#countdown").textContent = `${m}:${s}`;
  }, 1000);
}
function startAutoRefresh() {
  clearInterval(STATE.refreshTimer);
  STATE.refreshTimer = setInterval(() => fullRefresh(false), CONFIG.REFRESH_INTERVAL_MS);
}

function init() {
  bindFilterEvents();
  bindTableEvents();
  $("#refreshBtn").addEventListener("click", () => { fullRefresh(true); startCountdown(); });
  fullRefresh(true).then(() => { startCountdown(); startAutoRefresh(); });
}

document.addEventListener("DOMContentLoaded", init);
