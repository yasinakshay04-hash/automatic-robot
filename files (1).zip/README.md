# Paxel Commercial Performance Dashboard

Dashboard monitoring performa Commercial secara real-time, dibangun dengan HTML, CSS, JavaScript, Chart.js, dan PapaParse — tanpa framework.

## Cara menjalankan
Buka `index.html` di browser (double-click, atau lewat local server seperti Live Server di VS Code).
Tanpa konfigurasi apa pun, dashboard langsung berjalan menggunakan **data simulasi 90 hari** agar Anda bisa melihat semua fitur bekerja.

## Menghubungkan ke Google Sheets Anda
1. Buka Google Sheets Anda.
2. **File → Share → Publish to web**.
3. Pilih sheet yang berisi data, format **Comma-separated values (.csv)**, lalu klik **Publish**.
4. Copy link yang dihasilkan.
5. Buka `script.js`, cari baris paling atas:
   ```js
   const CONFIG = {
     SHEET_CSV_URL: "PASTE_GOOGLE_SHEET_CSV_URL_DISINI",
     ...
   };
   ```
6. Ganti nilainya dengan link CSV Anda. Simpan file. Selesai — **tidak perlu mengubah kode lain**.

### Kolom wajib di Google Sheets (header harus persis sama)
| Kolom | Keterangan |
|---|---|
| Tanggal | format `dd/mm/yyyy` atau `yyyy-mm-dd` |
| Regional | nama regional |
| Branch | nama cabang |
| BD | nama Business Development |
| Seller | nama/kode seller |
| Service | jenis layanan pengiriman |
| Shipment | jumlah paket (angka) |
| Revenue | total revenue (angka, tanpa simbol Rp) |
| Target Shipment | target jumlah paket |
| Target Revenue | target revenue |
| Status Seller | `Active` atau `Inactive` |
| New Seller | `Y`/`Yes`/`1` jika seller baru pada baris tsb |
| Lost Seller | `Y`/`Yes`/`1` jika seller churn pada baris tsb |
| Achievement | opsional, dihitung otomatis jika kosong |
| Growth | opsional, dihitung otomatis jika kosong |

Kolom **Channel** bersifat opsional — jika tidak ada di sheet, dashboard akan menebaknya otomatis dari nama Service.

## Fitur utama
- 9 KPI card dengan indikator naik/turun otomatis
- 8 filter cascading (Tanggal, Bulan, Regional, Branch, BD, Channel, Service, Seller)
- 20 grafik (trend, per-branch, per-service, gauge, funnel, pareto, heatmap, forecast 30 hari, dll)
- Tabel interaktif: search, sort per kolom, pagination, export Excel/CSV/PDF
- Alert otomatis (shipment/revenue turun >20%, seller inactive >7 hari, target belum tercapai, growth negatif)
- Panel AI Insight (narasi otomatis berbasis aturan/statistik dari data — bisa ditingkatkan ke pemanggilan API AI sungguhan bila diperlukan)
- Ranking Top 10 / Bottom 10 Branch, BD, Seller
- Auto-refresh data setiap 5 menit tanpa reload browser (bisa diubah lewat `REFRESH_INTERVAL_MS` di `script.js`)

## Struktur file
```
index.html   → struktur halaman & elemen UI
style.css    → tema warna (ungu #5E2B97, kuning #FFC72C, putih, abu muda) & layout responsif
script.js    → seluruh logika: load data, filter, KPI, chart, tabel, alert, insight, auto-refresh
```

## Kustomisasi cepat
- Warna tema: ubah di `CONFIG.COLORS` (script.js) dan variabel CSS di bagian atas `style.css`.
- Interval refresh: `CONFIG.REFRESH_INTERVAL_MS`.
- Jumlah baris per halaman tabel: `CONFIG.ROWS_PER_PAGE`.
- Target achievement default: `CONFIG.DEFAULT_TARGET_ACHIEVEMENT`.
